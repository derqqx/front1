just the assignments
